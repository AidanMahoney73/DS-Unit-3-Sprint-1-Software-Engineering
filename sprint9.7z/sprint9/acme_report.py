# My Imports
import random
from acme import Product

# Lists
ADJECTIVES = ['Awesome', 'Shiny', 'Impressive', 'Portable', 'Improved']
NOUNS = ['Anvil', 'Catapult', 'Disguise', 'Mousetrap', '???']


def generate_products(num_products=30):
    products = []
    # TODO - your code! Generate and add random products.
    for num in range(num_products):
        prod = Product(
            f'{random.sample(ADJECTIVES, 1)[0]} {random.sample(NOUNS, 1)[0]}')
        products.append(prod)
    return products


def inventory_report(products):
    names = []
    prices = 0
    weights = 0
    flames = 0
    for num in range(len(products)):
        names.append(products[num].name)
        prices += products[num].price
        weights += products[num].weight
        flames += products[num].flam
    mean_price = prices / len(products)
    mean_weight = weights / len(products)
    mean_flames = flames / len(products)
    print(
        f'ACME CORPORATION OFFICIAL INVENTORY REPORT\n'
        f'Number of Unique Names: {len(set(names))}\n'
        f'Average Price: {mean_price}\n'
        f'Average weight: {mean_weight}\n'
        #f'List Length: {len(names)}\n' # This is for testing
        f'Average Flammability: {mean_flames}')

if __name__ == '__main__':
    inventory_report(generate_products())
