prod2 = generate_products()
# checks that the generated names for a default batch of 
# products are all valid possible names to generate (adjective, space, noun)
for num in range(len(prod2)):
    name = prod2[num].name
    self.assertTrue((name.split()[0] in ADJECTIVES) & (name.split()[1] in NOUNS))