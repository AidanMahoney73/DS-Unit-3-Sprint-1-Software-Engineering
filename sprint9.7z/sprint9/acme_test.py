import unittest
from acme import Product
from acme_report import generate_products, ADJECTIVES, NOUNS


class AcmeProductTests(unittest.TestCase):
    #"""Making sure Acme products are the tops!"""
    def test_default_product_price(self):
        #"""Test default product price being 10."""
        prod = Product('Test Product')
        # self.assertEqual(prod.price, 10) # This is a Template

        # tests default values (as shown) [Completed]
        self.assertTrue((5 <= prod.price) & (prod.price <= 100))
        self.assertTrue((5 <= prod.weight) & (prod.weight <= 100))
        self.assertTrue((0 <= prod.flam) & (prod.flam <= 2.5))
        self.assertTrue((1000000 <= prod.ident) & (prod.ident <= 9999999))

        #builds an object with different values and ensures their stealability() and explode() methods function
        if prod.price/prod.weight < 0.5:
            self.assertEqual(prod.stealable(), "Not so stealable...")
        elif (prod.price/prod.weight >= 0.5) & (prod.price/prod.weight < 1):
            self.assertEqual(prod.stealable(), "Kinda stealable.")
        else:
            self.assertEqual(prod.stealable(), "Very stealable!")

        if prod.flam * prod.weight < 10:
            self.assertEqual(prod.explosive(), "...fizzle.")
        elif (prod.flam * prod.weight >= 10) & (prod.flam * prod.weight < 50):
            self.assertEqual(prod.explosive(), "...boom!")
        else:
            self.assertEqual(prod.explosive(), "...BABOOM!!")

class AcmeReportTests(unittest.TestCase):
    def test_default_num_products(self):
        prod2 = generate_products()
        # checks that it really does receive a list of length 30
        self.assertEqual(len(prod2), 30)

    def test_legal_names(self):
        prod2 = generate_products()
        # checks that the generated names for a default batch of 
        # products are all valid possible names to generate (adjective, space, noun)
        # for num in range(len(prod2)):
        #     name = prod2[num].name
        #     self.assertTrue((name.split()[0] in ADJECTIVES) & (name.split()[1] in NOUNS))
        for prod in prod2:
            full_name = prod.name.split()
            self.assertIn(full_name[0], ADJECTIVES)
            self.assertIn(full_name[1], NOUNS)





if __name__ == '__main__':
    test_classes = [AcmeProductTests, AcmeReportTests]

    loader = unittest.TestLoader()
    tests_list = []
    for test in test_classes:
        suite = loader.loadTestsFromTestCase(test)
        tests_list.append(suite)

    all_tests = unittest.TestSuite(tests_list)

    final = unittest.TextTestRunner()
    final.run(all_tests)


    # unittest.main() # Old line to run 1 test
    # prod = Product('Test Product') # This was to test output
    # print(prod.stealable()) # This was to test output


''' Directions for this section
Add at least 2 more test methods to AcmeProductTests for the base Product class: at 
least 1 that tests default values (as shown), and one that builds an object with 
different values and ensures their stealability() and explode() methods function as 
they should

Write a new test class AcmeReportTests with at least 2 test methods: 
test_default_num_products which checks that it really does receive a list of length 
30, and test_legal_names which checks that the generated names for a default batch 
of products are all valid possible names to generate (adjective, space, noun, from 
the lists of possible words)
'''
