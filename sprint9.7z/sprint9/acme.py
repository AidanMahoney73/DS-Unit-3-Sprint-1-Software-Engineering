import random


class Product():
    def __init__(self, name):
        self.name = name
        self.price = random.randint(5, 100)
        self.weight = random.randint(5, 100)
        self.flam = random.uniform(0, 2.5)
        self.ident = random.randint(1000000, 9999999)

    def stealable(self):
        steath = self.price / self.weight
        if steath < 0.5:
            return("Not so stealable...")
        elif (steath >= 0.5) & (steath < 1):
            return("Kinda stealable.")
        else:
            return("Very stealable!")

    def explosive(self):
        boom = self.flam * self.weight
        if boom < 10:
            return("...fizzle.")
        elif (boom >= 10) & (boom < 50):
            return("...boom!")
        else:
            return("...BABOOM!!")


class BoxingGlove():
    def __init__(self, name):
        self.name = name
        self.price = 10
        self.weight = 10
        self.flam = .5
        self.ident = random.randint(1000000, 9999999)

    def stealable(self):
        steath = self.price / self.weight
        if steath < 0.5:
            return("Not so stealable...")
        elif (steath >= 0.5) & (steath < 1):
            return("Kinda stealable.")
        else:
            return("Very stealable!")

    def explosive(self):
        return("...it's a glove.")

    def punch(self):
        if self.weight < 5:
            return("That tickles.")
        elif (self.weight >= 5) & (self.weight < 15):
            return("Hey that hurt!")
        else:
            return("OUCH!")
