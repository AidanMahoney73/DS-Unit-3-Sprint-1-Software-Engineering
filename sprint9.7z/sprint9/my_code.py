from acme import Product, BoxingGlove
import random
prod = Product('A Cool Toy')
print(prod.name)
print(prod.price)
print(prod.weight)
print(prod.flam)
print(prod.ident)
print(prod.stealable())
print(prod.explosive())

print("======================")

glove = BoxingGlove('Punchy the Third')
print(glove.price)
print(glove.weight)
print(glove.punch())
print(glove.explosive())